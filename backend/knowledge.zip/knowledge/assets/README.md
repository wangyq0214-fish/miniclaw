# Knowledge Assets

此目录用于存储知识库相关的静态资源文件（图片、图表等）。

## 使用方法

1. 将图片文件放到此目录：`backend/knowledge/assets/`

2. 在 Markdown 文件中引用：
```markdown
![图片描述](image.png)
```

3. 前端会自动加载：`http://localhost:8002/static/knowledge/assets/image.png`

## 注意事项

- 此目录下的文件不会显示在前端资源库中
- 仅用于存储图片等静态资源
- 支持的格式：PNG, JPG, JPEG, GIF, WebP, SVG
